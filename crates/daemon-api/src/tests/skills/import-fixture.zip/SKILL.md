---
name: zip-fixture
description: Inert fixture
---
Fixture instructions
